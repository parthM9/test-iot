export const GeoLocationQueue = "geolocation";
export const RawEventsDeadletterQueue = "deadletter-rawevents";
export const GeoLocationDeadletterQueue = "deadletter-geolocation";
export const NewConsignmentQueue = "newconsignmnets";
export const NewConsignmentDeadletterQueue = "newconsignmnets-deadletter";
