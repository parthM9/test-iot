export const GOOGLE_API_KEY = 'AIzaSyA3DgnfUpu77CoknzqRQ9SvBfhn3HfZyvc';
