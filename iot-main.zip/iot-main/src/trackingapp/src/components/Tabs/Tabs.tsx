import React from "react";

function Tabs(_props: any) {
  return (
    <React.Fragment></React.Fragment>
  );
}

export default Tabs;