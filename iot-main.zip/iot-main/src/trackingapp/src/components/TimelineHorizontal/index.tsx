import TimelineHorizontal from "./TimelineHorizontal";
export default TimelineHorizontal;