import ConsignmentDetails from "./ConsignmentDetails";
export default ConsignmentDetails;