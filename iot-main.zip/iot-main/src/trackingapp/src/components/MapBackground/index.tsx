import MapBackground from './MapBackground';
export default MapBackground;