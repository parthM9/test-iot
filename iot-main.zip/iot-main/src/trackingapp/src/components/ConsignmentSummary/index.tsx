import ConsignmentSummary from "./ConsignmentSummary";
export default ConsignmentSummary;