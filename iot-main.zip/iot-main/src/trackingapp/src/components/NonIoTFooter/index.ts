import NonIoTFooter from "./NonIoTFooter";
export default NonIoTFooter;