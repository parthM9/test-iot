import NonIoTLayout from "./NonIoTLayout";
export default NonIoTLayout;