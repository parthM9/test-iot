import MostRecentUpdate from "./MostRecentUpdate";
export default MostRecentUpdate;