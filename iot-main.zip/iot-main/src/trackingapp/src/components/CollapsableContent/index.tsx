import CollapsableContent from "./CollapsableContent";
export default CollapsableContent;