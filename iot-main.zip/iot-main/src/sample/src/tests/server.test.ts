describe("practiceSolution", () => {
  it("should be a function", () => {
    expect(true).toBeTruthy();
  });
});
